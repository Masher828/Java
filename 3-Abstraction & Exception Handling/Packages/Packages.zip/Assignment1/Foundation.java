package test;
public class Foundation{
	private int m1=10;
	protected int m2=11;
	public int m3=12;
	int m4=13;
}