import test.Foundation;
public class Assignment1{
	public static void main(String[] args){
		Foundation found = new Foundation();
		//System.out.println(found.m1);
		//System.out.println(found.m2);
		System.out.println(found.m3);
		//System.out.println(found.m4);
	}
}