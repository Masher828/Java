package com.wipro.automobile.ship;
public class Compartment{
	public double height;
	public double width;
	public double weight;
}