import java.util.*;
public class Assignment4{
	public static void main(String[] args){
	ArrayList<Number> list = new ArrayList<Number>();
	list.add(10);
	list.add(10.2);
	list.add(3.4);
	list.add(4.5f);
	list.add(33);
	for(Object ele : list){
		System.out.println(ele);
	}
	}
}
	 
		