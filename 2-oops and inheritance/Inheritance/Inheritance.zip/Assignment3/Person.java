class Person{
	String name;
	String dateOfBirth;
	Person(String name,String dob){
		this.name=name;
		dateOfBirth=dob;
	}
	String getName(){
		return name;
	}
	String getDOB(){
		return dateOfBirth;
	}

	
}
