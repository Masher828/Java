class Person{
	String name;
	void setName(String name){
		this.name =name;
	}
	
	String getName(){
		return name;
	}
	}