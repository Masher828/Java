
public class Demo1 {
String stringConcat(String abc, String xyz) {
	return abc+xyz;
}
}
